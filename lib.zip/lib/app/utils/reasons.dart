
class Reasons {
  static const List<String> cancelReasons = [
    "Got same quality in Better price somewhare",
    "Change your mind",
    "No longer needed",
    "Order by mistake",
    "Change delevery date",
    "Other",
  ];

  static const List<String> returnReasons = [
    "Product Not working Propperly",
    "Recicved Daimage Product",
    "Cable & Accessories Missing",
    "Quality is not like as you want",
    "Notepad to express their problem deeply with words limit",
    "Other",
  ];
}
