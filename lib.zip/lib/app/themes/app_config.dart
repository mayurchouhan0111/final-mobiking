class AppConfig {
  static const String baseUrl = 'https://boxbudy.com/api/v1';
}
